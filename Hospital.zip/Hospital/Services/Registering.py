from Hospital.Services.Service import *


# Registering class - inherits from Service


class Registering(Service):
    def __init__(self, name="Registering"):
        self.name = name
        self.r_p = 0

    @property
    def final_result(self):
        return {
            "name": self.name
        }

    def discharge(self, patient): # has in doctor
        if patient.registering_status:
            patient.registering_status = False
        else:
            return "The patient has already been discharged." # maybe create an error for this?

    def status(self, patient):
        if patient.registering_status:
            return f"The patient {patient.name} is currently admitted in our hospital."
        else:
            return f"The patient {patient.name} has been discharged from our hospital."