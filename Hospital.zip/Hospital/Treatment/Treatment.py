class Treatment:
    def __init__(self, name=None):
        self.name = name

    def give_treatment(self, patient):
        return f"{patient.name} got a treatment"